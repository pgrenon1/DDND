I was playing on SM until I discovered this song with another .DWI.
The steps were horrible.

Miranda_Q7G wrote this: "spend some time trying to feel the step logic".

STEP LOGIC?!!!! MY FOOT!!! This was as crap as my first songs...

So I decided to remake some real steps.